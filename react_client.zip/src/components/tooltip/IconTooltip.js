// React base
import React, { Component } from 'react';

// Bootstrap
import { Tooltip } from 'reactstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

class IconTooltip extends Component {
    constructor(props) {
        super(props);

        this.toggle = this.toggle.bind(this);
        this.state = {
            tooltipOpen: false
        };
    }

    toggle() {
        this.setState({
            tooltipOpen: !this.state.tooltipOpen
        });
    }

    render() {
        return (
            <span>
                <span onClick={this.props.onNodeConfigPanelFullscreenToggle} id={'IconTooltip-' + this.props.id}>
                    <FontAwesomeIcon icon={this.props.icon} />
                </span>
                <Tooltip placement={this.props.tooltipPlacement} isOpen={this.state.tooltipOpen} target={'IconTooltip-' + this.props.id} toggle={this.toggle}>
                    {this.props.tooltipText}
                </Tooltip>
            </span>
        );
    }
}

export default IconTooltip;
