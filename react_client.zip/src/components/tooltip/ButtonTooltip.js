// React base
import React, { Component } from 'react';

// Bootstrap
import { Button, Tooltip } from 'reactstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

class ButtonTooltip extends Component {
    constructor(props) {
        super(props);

        this.toggle = this.toggle.bind(this);
        this.state = {
            tooltipOpen: false
        };
    }

    toggle() {
        this.setState({
            tooltipOpen: !this.state.tooltipOpen
        });
    }

    render() {
        return (
            <span>
                <Button outline color={this.props.color} id={'ButtonTooltip-' + this.props.id} onClick={this.props.onClick} size={this.props.size}>
                    {this.props.type === 'icon' ? <FontAwesomeIcon icon={this.props.icon} /> : this.props.text}
                </Button>
                <Tooltip placement={this.props.tooltipPlacement} isOpen={this.state.tooltipOpen} target={'ButtonTooltip-' + this.props.id} toggle={this.toggle}>
                    {this.props.tooltipText}
                </Tooltip>
            </span>
        );
    }
}

export default ButtonTooltip;
