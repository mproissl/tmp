// React base
import React from 'react';

// Styles
import './styles/node-view-generator.css';

/**
 * Supported node content
 * Note: this must be in-line with available classes
 *       in node-view-generator.css as well as respective
 *       icons in ./img/*
 */
const nodeContent = ['py','R','db'];

/**
 * Component that renders a node objects type, along with icons
 * representing the respective content (e.g. code or data)
 */
function NodeObject({ obj }) {

    // Icon type: default based on node type
    let icon_type = (obj._nodeType === 'fo') ? 'default-fo': 'default-do';

    // Icon type: split if node content is set
    if(nodeContent.includes(obj._nodeContent)) {
        icon_type = obj._nodeContent;
    }

    return (
        <div className={`flex-container obj-node ${obj._nodeType}`} title={`${obj._nodeTooltip}`}>
            <div className="name">{obj._nodeTitle}</div>

            <div className={`flex-container fill-space flex-container-row icon ${icon_type}`} />
        </div>
    );
}

export default NodeObject;
