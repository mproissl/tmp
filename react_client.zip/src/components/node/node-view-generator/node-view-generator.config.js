import React from 'react';
import NodeViewGenerator from './NodeViewGenerator';

var defaultConfig = {
    directed: true,
    automaticRearrangeAfterDropNode: false,
    collapsible: false,
    height: 800,
    highlightDegree: 1,
    highlightOpacity: 0.2,
    linkHighlightBehavior: true,
    maxZoom: 8,
    minZoom: 0.1,
    nodeHighlightBehavior: true,
    panAndZoom: false,
    staticGraph: false,
    width: 800,
    node: {
        color: '#d3d3d3',
        fontColor: 'black',
        fontSize: 12,
        fontWeight: 'normal',
        highlightColor: 'red',
        highlightFontSize: 12,
        highlightFontWeight: 'bold',
        highlightStrokeColor: 'SAME',
        highlightStrokeWidth: 1.5,
        labelProperty: 'id',
        mouseCursor: 'pointer',
        opacity: 1,
        renderLabel: false,
        size: 700,
        strokeColor: 'none',
        strokeWidth: 1.5,
        svg: '',
        symbolType: 'circle',
        viewGenerator: node => <NodeViewGenerator obj={node} />
    },
    link: {
        color: '#d3d3d3',
        opacity: 1,
        semanticStrokeWidth: false,
        strokeWidth: 2,
        highlightColor: 'green'
    }
};

export default defaultConfig;
