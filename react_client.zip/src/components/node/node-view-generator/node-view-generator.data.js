module.exports = {
    links: [
        {
            source: 1,
            target: 2
        },
        {
            source: 2,
            target: 3
        },
        {
            source: 1,
            target: 3
        },
        {
            source: 3,
            target: 4
        }
    ],
    nodes: [
        {
            id: 1,
            _nodeType: 'fo',
            _nodeName: 'A',
            _nodeTitle: 'A',
            _nodeTooltip: 'Node A',
            _nodeContent: 'py',
            _nodeDescription: '',
            _nodeConfig: {
                type: 'code',
                interpreter: 'python',
                data: ''
            }
        },
        {
            id: 2,
            _nodeType: 'do',
            _nodeName: 'B',
            _nodeTitle: 'B',
            _nodeTooltip: 'Node B',
            _nodeContent: 'db',
            _nodeDescription: '',
            _nodeConfig: {
                type: 'file',
                interpreter: 'excel',
                data: ''
            }
        },
        {
            id: 3,
            _nodeType: 'fo',
            _nodeName: 'C',
            _nodeTitle: 'C',
            _nodeTooltip: 'Node C',
            _nodeContent: 'py',
            _nodeDescription: '',
            _nodeConfig: {
                type: 'code',
                interpreter: 'python',
                data: ''
            }
        },
        {
            id: 4,
            _nodeType: 'fo',
            _nodeName: 'D',
            _nodeTitle: 'D',
            _nodeTooltip: 'Node D',
            _nodeContent: 'R',
            _nodeDescription: '',
            _nodeConfig: {
                type: 'code',
                interpreter: 'python',
                data: ''
            }
        }
    ]
};
