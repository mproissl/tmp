// React base
import React, { Component } from 'react';

// Third Parties
import AceEditor from 'react-ace';
import 'brace/mode/python';
import 'brace/theme/monokai';

// Bootstrap
import { FormGroup, Label, Input, FormText } from 'reactstrap';

// Components
import ButtonTooltip from "../../tooltip/ButtonTooltip";

// Styles
import './styles/node-config-panel.css';

/**
 * Component that renders a config panel for a (selected) node
 */
class NodeConfigPanel extends Component {

    /**
     * This function checks if all required keys are in node object
     * @param  {Object} node object
     * @return {Boolean} returns true if ALL keys are present
     */
    _hasAllRequiredKeys = node => {

        // Current required keys
        const required_keys = ['id','_nodeType','_nodeName','_nodeTitle','_nodeTooltip','_nodeContent','_nodeDescription','_nodeConfig'];
        const required_configs = ['type','interpreter','data'];

        for (const idx in required_keys) {
            if( !node.hasOwnProperty(required_keys[idx]) ) return false;
        }
        for (const idx in required_configs) {
            if( !node._nodeConfig.hasOwnProperty(required_configs[idx]) ) return false;
        }
        return true;
    };

    /**
     * This function creates an editor for coding functional
     * objects and on-change edits the state of the hosted node.
     * @param  {Object} node object
     * @return {Boolean} DIV of editor
     */
    _codeEditor = (nodeIndex, data, onDataUpdate) => {

        // Data
        const _data = data;

        // Mode: programming language
        let mode = null;
        switch( data.nodes[nodeIndex]._nodeContent ) {
            case 'py':
                mode = "python";
                break;
            default:
            // none
        }

        // Theme: fixed for now
        const theme = "monokai";

        // DIV identifier
        let div_id = data.nodes[nodeIndex]._nodeType + parseInt(data.nodes[nodeIndex].id);

        // Publish
        if( mode && theme ) {
            return (
                <AceEditor
                    mode={mode}
                    theme={theme}
                    value={_data.nodes[nodeIndex]._nodeConfig.data}
                    onChange={ (val) => { _data.nodes[nodeIndex]._nodeConfig.data = val; onDataUpdate(_data); }}
                    name={div_id}
                    key={div_id}
                    editorProps={{$blockScrolling: false}}
                    wrapEnabled={true}
                    width='100%'
                    height='100%'
                />
            );
        }
        return null;
    };

    /**
     * This function returns the selected node index
     * @param  {Number} id Identifier of selected node
     * @param  {Object} nodes Graph nodes
     * @return {Object} selected node index or null if not found
     */
    getSelectedNodeIndex = (id, nodes) => {

        // Sanity check: null/nan test
        if( !nodes || !id ) return null;

        // Retrieve node
        try {
            id = parseInt(id);
            const idx = nodes.findIndex(node => node.id === id);

            if (idx >= 0) {

                // Basic node object validation
                if( !this._hasAllRequiredKeys(nodes[idx]) ) return null;

                return idx;
            }
        }
        catch (err) {
            console.error(err);
        }
        return null;
    };

    /**
     * This function creates an error panel
     * @param  {String} msg Optional error message
     * @return {Object} DIV of respective config panel
     */
    getConfigPanel_Error = (msg = null) => {
        return (
            <div className="NodeConfigPanel-Body">
                <div className="NodeConfigPanel-Title">Oops! Something went wrong.</div>
                { msg ? <div className="NodeConfigPanel-ErrorMsg">{msg}</div> : null }
            </div>
        );
    };

    /**
     * This function creates a node config panel
     * @return {Object} DIV of respective config panel
     */
    getConfigPanel_Node = (nodeIndex, data, onDataUpdate) => {

        // Panel content
        let panel_content = [];
        const _data = data;

        // Title
        panel_content.push(<div key='title.header' className="NodeConfigPanel-Title">{_data.nodes[nodeIndex]._nodeTitle}</div>);

        // ID + Type
        panel_content.push(
            <div key='id.type' className="NodeConfigPanel-Header">
                <span className="NodeConfigPanel-Header_left" title='Node ID'>ID = {_data.nodes[nodeIndex].id}</span>
                <span className="NodeConfigPanel-Header_right" title='Node Type'>Type = {_data.nodes[nodeIndex]._nodeType}</span>
                <br />
            </div>
        );

        // Type
        panel_content.push(
            <div key='type' className="NodeConfigPanel-Common">
                <FormGroup>
                    <Label for="type">TYPE</Label>
                    <Input type="select" name="type" id="type" value={_data.nodes[nodeIndex]._nodeType} onChange={(e) => { _data.nodes[nodeIndex]._nodeType = e.target.value; onDataUpdate(_data); }}>
                        <option value='fo'>Functional Object (FO)</option>
                        <option value='do'>Data Object (DO)</option>
                    </Input>
                </FormGroup>
            </div>
        );

        // Name
        panel_content.push(
            <div key='name' className="NodeConfigPanel-Common">
                <FormGroup>
                    <Label for="name">NAME</Label>
                    <Input type="text" name="name" value={_data.nodes[nodeIndex]._nodeName} onChange={ (e) => { _data.nodes[nodeIndex]._nodeName = e.target.value; onDataUpdate(_data); }} />
                </FormGroup>
            </div>
        );

        // Title
        panel_content.push(
            <div key='title' className="NodeConfigPanel-Common">
                <FormGroup>
                    <Label for="title">TITLE</Label>
                    <Input type="text" name="title" id="title" value={_data.nodes[nodeIndex]._nodeTitle} onChange={ (e) => { _data.nodes[nodeIndex]._nodeTitle = e.target.value; onDataUpdate(_data); }} />
                </FormGroup>
            </div>
        );

        // Tooltip
        panel_content.push(
            <div key='tooltip' className="NodeConfigPanel-Common">
                <FormGroup>
                    <Label for="tooltip">TOOLTIP</Label>
                    <Input type="text" name="tooltip" id="tooltip" value={_data.nodes[nodeIndex]._nodeTooltip} onChange={ (e) => { _data.nodes[nodeIndex]._nodeTooltip = e.target.value; onDataUpdate(_data); }} />
                </FormGroup>
            </div>
        );

        // Content
        panel_content.push(
            <div key='content' className="NodeConfigPanel-Common">
                <FormGroup>
                    <Label for="content">CONTENT</Label>
                    <Input type="select" name="content" id="content" value={_data.nodes[nodeIndex]._nodeContent} onChange={ (e) => { _data.nodes[nodeIndex]._nodeContent = e.target.value; onDataUpdate(_data); }}>
                        <option value='py'>Python 3.5+</option>
                    </Input>
                </FormGroup>
            </div>
        );

        // Description
        panel_content.push(
            <div key='desc' className="NodeConfigPanel-Common">
                <FormGroup>
                    <Label for="desc">DESCRIPTION</Label>
                    <Input type="textarea" name="desc" id="desc" value={_data.nodes[nodeIndex]._nodeDescription} onChange={ (e) => { _data.nodes[nodeIndex]._nodeDescription = e.target.value; onDataUpdate(_data); }} />
                    <FormText color="muted">
                        Describe the content or purpose of this node.
                    </FormText>
                </FormGroup>
            </div>
        );

        // Config: FO
        if( _data.nodes[nodeIndex]._nodeType === 'fo' ) {
            panel_content.push(this._codeEditor(nodeIndex, data, onDataUpdate));
        }

        return (
            <div className="NodeConfigPanel-Body">
                {panel_content}
            </div>
        );
    };

    render() {

        // Node to be configured
        const nodeIndex    = this.getSelectedNodeIndex(this.props.data.focusedNodeId, this.props.data.nodes);
        let   config_panel = null;

        // Create config panel for this node
        if( nodeIndex !== null ) {

            // Create panel
            if( this.props.data.nodes[nodeIndex]._nodeType === 'fo' || this.props.data.nodes[nodeIndex]._nodeType === 'do' ) {
                config_panel = this.getConfigPanel_Node(nodeIndex, this.props.data, this.props.onDataUpdate);
            } else {
                config_panel = this.getConfigPanel_Error('Unknown Node Type.');
            }
        }
        // Return error panel
        else {
            config_panel = this.getConfigPanel_Error();
        }

        return (
            <div className={this.props.nodeConfigPanel_Fullscreen ? 'NodeConfigPanel-Fullscreen' : 'NodeConfigPanel'}>
                <div className='NodeConfigPanel-ResizeIcon'>
                    <ButtonTooltip color='secondary' type='icon' icon={this.props.nodeConfigPanel_Fullscreen ? 'angle-right' : 'angle-left'} id='resize-config-panel' tooltipPlacement='right' tooltipText='Resize' onClick={this.props.onNodeConfigPanelFullscreenToggle} size='sm' />
                </div>
                {config_panel}
            </div>
        );
    }
}

export default NodeConfigPanel;
