// React base
import React, { Component } from 'react';

// Bootstrap
import {Button, Modal, ModalHeader, ModalBody, ModalFooter, Alert} from 'reactstrap';

// Icons
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

// Style
import './modals.css'

class CreateLinkModal extends Component {
    render() {

        return (
            <div>
                <Modal isOpen={this.props.createLinkModal} toggle={this.props.onCreateLinkModalToggle}>
                    <ModalHeader toggle={this.props.onCreateLinkModalToggle}>Create a link</ModalHeader>
                    <ModalBody>
                        Shall we create the following link:

                        <div className='CodeCentered'>
                            <Alert color="primary">{this.props.sourceNode}</Alert>
                            <FontAwesomeIcon icon="angle-double-down" size="3x" color="gray" />
                            <Alert color="secondary">{this.props.targetNode}</Alert>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <Button color="primary" onClick={this.props.createNodeLink}>Create Link</Button>{' '}
                        <Button color="secondary" onClick={this.props.onCreateLinkModalToggle}>Cancel</Button>
                    </ModalFooter>
                </Modal>
            </div>
        );
    }
}

export default CreateLinkModal;
