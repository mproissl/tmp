/*eslint require-jsdoc: 0, valid-jsdoc: 0, no-undef: 0, no-empty: 0, no-console: 0*/
//import queryString from 'querystring';
import { LINE_TYPES } from '../../components/link/link.const';

/**
 * This two functions generate the react-jsonschema-form
 * schema from some passed graph configuration.
 */
function formMap(k, v) {
    // customized props
    switch (k) {
        case 'link.type': {
            return {
                type: 'array',
                title: 'link.type',
                items: {
                    enum: Object.keys(LINE_TYPES)
                },
                uniqueItems: true
            };
        }
        default: 
            // pass
    }

    return {
        title: k,
        type: typeof v,
        default: v
    };
}

function generateFormSchema(o, rootSpreadProp, accum = {}) {
    for (let k of Object.keys(o)) {
        const kk = rootSpreadProp ? `${rootSpreadProp}.${k}` : k;

        if (o[k] !== undefined && o[k] !== null && typeof o[k] !== 'function') {
            typeof o[k] === 'object' ? generateFormSchema(o[kk], kk, accum) : (accum[kk] = formMap(kk, o[k]));
        }
    }

    return accum;
}

function loadDataset() {

    const config = {};
    const data = require('../../components/node/node-view-generator/node-view-generator.data');

    return {
        config,
        data
    };
}

function setValue(obj, access, value) {
    if (typeof access === 'string') {
        access = access.split('.');
    }

    // check for non existence of root property before advancing
    if (!obj[access[0]]) {
        obj[access[0]] = {};
    }

    access.length > 1 ? setValue(obj[access.shift()], access, value) : (obj[access[0]] = value);
}

export default {
    generateFormSchema,
    loadDataset,
    setValue
};