// React base
import React, { Component } from 'react';
import { Link } from 'react-router-dom';

// Builder components
import { Graph } from '../../components';
import NodeDefaultCfg from '../../components/node/node-view-generator/node-view-generator.config';
import NodeConfigPanel from '../../components/node/node-config-panel/NodeConfigPanel';
import ButtonTooltip from '../../components/tooltip/ButtonTooltip';

// Modals
import CreateLinkModal from './modals/CreateLinkModal';
import DeleteLinkModal from './modals/DeleteLinkModal';
import CreateNodeModal from './modals/CreateNodeModal';

// Utils
import utils from './BuilderUtils'

// Styles
import './Builder.css';
import logo from '../../img/ubs-logo-white.svg';

// Test data
const testData = utils.loadDataset();

// Main class
class Builder extends Component {

  // Constructor
  constructor(props) {
        super(props);
        
        // Settings
        const { config: configOverride, data } = testData;
        const config = Object.assign(NodeDefaultCfg, configOverride);
        const schemaProps = utils.generateFormSchema(config, '', {});
        
        // Schema
        const schema = {
            type: 'object',
            properties: schemaProps
        };

        // Bindings
        this.onDataUpdate = this.onDataUpdate.bind(this);
        this.onDisplayControlUpdate = this.onDisplayControlUpdate.bind(this);
        this.onNodeConfigPanelFullscreenToggle = this.onNodeConfigPanelFullscreenToggle.bind(this);

        this.onCreateNodeModalToggle = this.onCreateNodeModalToggle.bind(this);

        this.createNodeLink = this.createNodeLink.bind(this);
        this.onCreateLinkModalToggle = this.onCreateLinkModalToggle.bind(this);

        this.deleteNodeLink = this.deleteNodeLink.bind(this);
        this.onDeleteLinkModalToggle = this.onDeleteLinkModalToggle.bind(this);

        // Display control
        const displayControl = {
            // NodeConfigPanel
            nodeConfigPanel_Id: true,
            nodeConfigPanel_Links:false,
            nodeConfigPanel_Content: false,
            nodeConfigPanel_Fullscreen: false,
            // GraphControlPanel
            graphControlPanel: true,
            // CreateNodeModal
            createNodeModal: false,
            // CreateLinkModal
            createLinkModal: false,
            createLinkModal_Source: -1,
            createLinkModal_Target: -1,
            // DeleteLinkModal
            deleteLinkModal: false,
            deleteLinkModal_Source: -1,
            deleteLinkModal_Target: -1
        };

        // State
        this.state = {
            config,
            generatedConfig: {},
            schema,
            data,
            displayControl
        };
    }

    /*******************************************************************************************************************
     * Internal '_' methods
     *******************************************************************************************************************/

    /**
     * Check if a new link request is valid
     * @param  {Number} source ID of source node
     * @param  {Number} target ID of target node
     * @returns {Boolean} flag if link valid
     */
    _isNewLinkValid = (source, target) => {

        // Check 1: source, target identical
        if( source === target ) {
            return false;
        }

        // Check 2: respective nodes exist
        let source_idx = this.state.data.nodes.findIndex(node => node.id === source);
        let target_idx = this.state.data.nodes.findIndex(node => node.id === target);
        if( source_idx < 0 || target_idx < 0 ) {
            return false;
        }

        // Check 3: directed link does exist already (if the other way, we plan to switch)
        if( this.state.data.links.findIndex(link => (link.source === source && link.target === target)) >= 0 ) {
            return false;
        }

        return true;
    };

    /**
     * Extract the node value by given node id and node attribute
     * @param  {Number} id ID of a node
     * @param  {String} attribute Name of a node's attribute
     * @returns {String} value of an attribute
     */
    _attributeOfNode = (id, attribute) => {
        const idx = this.state.data.nodes.findIndex(node => node.id === id);
        if( idx >= 0 ) {
            if( this.state.data.nodes[idx].hasOwnProperty(attribute) ) {
                return( this.state.data.nodes[idx][attribute] );
            }
        }
        return('Not Found.');
    };

    /*******************************************************************************************************************
     * State update methods
     *******************************************************************************************************************/

    /**
     * Event Handler: Update of state: [data]
     * @param  {Object} data State data to be updated
     * @returns {undefined}
     */
    onDataUpdate = data => {
        this.setState({
            data
        });
    };

    /**
     * Event Handler: Update of state: [displayControl]
     * @param  {Object} displayControl State displayControl to be updated
     * @returns {undefined}
     */
    onDisplayControlUpdate = displayControl => {
        this.setState({
            displayControl
        });
    };

    /**
     * Event Handler: Toggle of state: [displayControl.createNodeModal]
     * @returns {undefined}
     */
    onCreateNodeModalToggle = () => {
        const _displayControl = Object.assign(this.state.displayControl, {
            createNodeModal: !this.state.displayControl.createNodeModal
        });
        this.onDisplayControlUpdate(_displayControl);
    };

    /**
     * Event Handler: Toggle of state: [displayControl.createLinkModal]
     * @returns {undefined}
     */
    onCreateLinkModalToggle = () => {
        const _displayControl = Object.assign(this.state.displayControl, {
            createLinkModal: !this.state.displayControl.createLinkModal
        });
        this.onDisplayControlUpdate(_displayControl);
    };

    /**
     * Event Handler: Toggle of state: [displayControl.deleteLinkModal]
     * @returns {undefined}
     */
    onDeleteLinkModalToggle = () => {
        const _displayControl = Object.assign(this.state.displayControl, {
            deleteLinkModal: !this.state.displayControl.deleteLinkModal
        });
        this.onDisplayControlUpdate(_displayControl);
    };

    /**
     * Event Handler: Toggle of state: [displayControl.nodeConfigPanel_Fullscreen]
     * @returns {undefined}
     */
    onNodeConfigPanelFullscreenToggle = () => {
        const _displayControl = Object.assign(this.state.displayControl, {
            nodeConfigPanel_Fullscreen: !this.state.displayControl.nodeConfigPanel_Fullscreen
        });
        this.onDisplayControlUpdate(_displayControl);
    };

    /*******************************************************************************************************************
     * Event Handlers of the Graph
     *******************************************************************************************************************/

    /**
     * Event Handler: (Left) Click on Graph canvas
     * #DISABLED for now
     */
    onClickGraph = undefined;
    
    /**
     * Event Handler: (Left) Click on a Node
     * This sets the focusedNodeId to ID of clicked node and thus triggers the focusAnimation,
     * i.e. moving the clicked node to the center of the Graph canvas.
     * @param  {string} id - id of the node that participates in the event.
     * @returns {undefined}
     */
    onClickNode = id => {
        this.setState({
           data: {
               ...this.state.data,
               focusedNodeId: this.state.data.focusedNodeId !== id ? id : null
           }
        });
    };
    
    /**
     * Event Handler: (Right) Click on a Node
     * This triggers the display of a modal to add a link to the right-clicked node
     * from the left-clicked (focusedNode) node.
     * @param  {Object} event User event from a node
     * @param  {Number} id Node ID
     * @returns {undefined}
     */
    onRightClickNode = (event, id) => {

        // Check source node selected
        if( this.state.data.focusedNodeId ) {
            // Check if requested link is valid
            if( this._isNewLinkValid(parseInt(this.state.data.focusedNodeId), parseInt(id)) ) {
                const _displayControl = Object.assign(this.state.displayControl, {
                    createLinkModal: true,
                    createLinkModal_Source: parseInt(this.state.data.focusedNodeId),
                    createLinkModal_Target: parseInt(id)
                });
                this.onDisplayControlUpdate(_displayControl);
            }
        }
        event.preventDefault();
    };
    
    /**
     * Event Handler: (Left) Click on a Link
     * #DISABLED for now
     */
    //onClickLink = (source, target) => window.alert(`Clicked link between ${source} and ${target}`);
    onClickLink = undefined;
    
    /**
     * Event Handler: (Right) Click on a Link
     * This triggers the display of a modal to delete the selected link.
     * @param  {Object} event User event from a node
     * @param  {String} source Address of source node
     * @param  {String} target Address of target node
     * @returns {undefined}
     */
    onRightClickLink = (event, source, target) => {
        // Update display state of respective modal
        const _displayControl = Object.assign(this.state.displayControl, {
            deleteLinkModal: true,
            deleteLinkModal_Source: parseInt(source),
            deleteLinkModal_Target: parseInt(target)
        });
        this.onDisplayControlUpdate(_displayControl);
        event.preventDefault();
    };
    
    /**
     * Event Handler: Mouse over a Node
     * #DISABLED for now
     */
    //onMouseOverNode = id => console.info(`Do something when mouse is over node (${id})`);
    onMouseOverNode = undefined;
    
    /**
     * Event Handler: Mouse out of a Node
     * #DISABLED for now
     */
    //onMouseOutNode = id => console.info(`Do something when mouse is out of node (${id})`);
    onMouseOutNode = undefined;
    
    /**
     * Event Handler: Mouse over a Link
     * #DISABLED for now
     */
    /*onMouseOverLink = (source, target) =>
        console.info(`Do something when mouse is over link between ${source} and ${target}`);*/
    onMouseOverLink = undefined;
    
    /**
     * Event Handler: Mouse out of a Link
     * #DISABLED for now
     */
    /*onMouseOutLink = (source, target) =>
        console.info(`Do something when mouse is out of link between ${source} and ${target}`);*/
    onMouseOutLink = undefined;
    
    /**
     * Event Handler: Toggle fullscreen
     * #DISABLED - not needed anymore
     */
    onToggleFullScreen = undefined;

    /**
     * PASS-THROUGH-FCN: restart graph simulation
     * #DISABLED for now
     */
        //restartGraphSimulation = () => this.refs.graph.restartSimulation();
    restartGraphSimulation = undefined;

    /**
     * PASS-THROUGH-FCN: pause graph simulation
     * #DISABLED for now
     */
        //pauseGraphSimulation = () => this.refs.graph.pauseSimulation();
    pauseGraphSimulation = undefined;

    /**
     * PASS-THROUGH-FCN: reset node positions
     * #DISABLED for now
     */
        //resetNodesPositions = () => this.refs.graph.resetNodesPositions();
    resetNodesPositions = undefined;

    /*******************************************************************************************************************
     * Action methods for interfaces
     *******************************************************************************************************************/

    /**
     * Event Handler: Click on Create Button of a dedicated modal to create a new node
     * @returns {undefined}
     */
    createNode = () => {



    };

    /**
     * Event Handler: Click on respective Create Button of a selected link
     * This triggers the display of a modal to add a link to the right-clicked node
     * from the left-clicked (focusedNode) node.
     * @returns {undefined}
     */
    createNodeLink = () => {

        // Pair
        const source = this.state.displayControl.createLinkModal_Source;
        const target = this.state.displayControl.createLinkModal_Target;

        // New link request is valid
        if( this._isNewLinkValid(source, target) ) {

            // New link
            const newLink = {
                source: source,
                target: target
            };

            // Switch current direction source <> target
            const _data = this.state.data;
            const switchIndex = _data.links.findIndex(link => (link.source === target && link.target === source));
            if( switchIndex >= 0 ) {
                _data.links.splice(switchIndex);
            }
            _data.links.push(newLink);

            // Reset display
            const _displayControl = Object.assign(this.state.displayControl, {
                createLinkModal: false,
                createLinkModal_Source: -2,
                createLinkModal_Target: -2
            });
            this.onDisplayControlUpdate(_displayControl);

            // Update state
            this.onDataUpdate(_data);
        }
    };

    /**
     * Event Handler: Click on respective Delete Button of a selected link
     * This triggers the display of a modal to delete a link.
     * @returns {undefined}
     */
    deleteNodeLink = () => {

        // Pair
        const source = this.state.displayControl.deleteLinkModal_Source;
        const target = this.state.displayControl.deleteLinkModal_Target;

        // Find & Delete
        const _data = this.state.data;
        const idx = _data.links.findIndex(link => ((link.source === source && link.target === target) || (link.source === target && link.target === source)));
        if( idx >= 0 ) {
            // Delete
            _data.links.splice(idx);

            // Reset display
            const _displayControl = Object.assign(this.state.displayControl, {
                deleteLinkModal: false,
                deleteLinkModal_Source: -2,
                deleteLinkModal_Target: -2
            });
            this.onDisplayControlUpdate(_displayControl);

            // Update data
            this.onDataUpdate(_data);
        }
    };

    /**
     * This function decorates nodes and links with random (initial) positions.
     * @param  {Object} nodes and links with minimalist structure.
     * @return {Object} the graph where now nodes containing (x,y) coords.
     */
    decorateGraphNodesWithInitialPositioning = nodes => {
        return nodes.map(n =>
            Object.assign({}, n, {
                x: n.x || Math.floor(Math.random() * 500),
                y: n.y || Math.floor(Math.random() * 500)
            })
        );
    };

    /*******************************************************************************************************************
     * Render the Builder App
     *******************************************************************************************************************/

    // Render builder
    render() {
        // This does not happens in this sandbox scenario running time, but if we set staticGraph config
        // to true in the constructor we will provide nodes with initial positions
        const data = {
            nodes: this.decorateGraphNodesWithInitialPositioning(this.state.data.nodes),
            links: this.state.data.links,
            focusedNodeId: this.state.data.focusedNodeId
        };
        
        // Properties of graph
        const graphProps = {
            id: 'graph',
            data,
            config: this.state.config,
            onClickNode: this.onClickNode,
            onRightClickNode: this.onRightClickNode,
            onClickGraph: this.onClickGraph,
            onClickLink: this.onClickLink,
            onRightClickLink: this.onRightClickLink,
            onMouseOverNode: this.onMouseOverNode,
            onMouseOutNode: this.onMouseOutNode,
            onMouseOverLink: this.onMouseOverLink,
            onMouseOutLink: this.onMouseOutLink
        };
        
        // Fullscreen by default
        graphProps.config = Object.assign({}, graphProps.config, {
            height: window.innerHeight,
            width: window.innerWidth
        });

        // Publish builder
        return (
            <div className="Builder-container">
                <div className="TopBar">
                    <Link to='/'>
                        <img src={logo} className="TopBarLogo" alt="logo" />
                    </Link>
                    <div>Analytics Pipeline Builder</div>
                </div>
                { this.state.displayControl.createNodeModal ? <CreateNodeModal createNodeModal={this.state.displayControl.createNodeModal} onCreateNodeModalToggle={this.onCreateNodeModalToggle} createNode={this.createNode} /> : null }
                { this.state.displayControl.createLinkModal ? <CreateLinkModal sourceNode={this._attributeOfNode(this.state.displayControl.createLinkModal_Source, '_nodeName')} targetNode={this._attributeOfNode(this.state.displayControl.createLinkModal_Target, '_nodeName')} createLinkModal={this.state.displayControl.createLinkModal} onCreateLinkModalToggle={this.onCreateLinkModalToggle} createNodeLink={this.createNodeLink} /> : null }
                { this.state.displayControl.deleteLinkModal ? <DeleteLinkModal sourceNode={this._attributeOfNode(this.state.displayControl.deleteLinkModal_Source, '_nodeName')} targetNode={this._attributeOfNode(this.state.displayControl.deleteLinkModal_Target, '_nodeName')} deleteLinkModal={this.state.displayControl.deleteLinkModal} onDeleteLinkModalToggle={this.onDeleteLinkModalToggle} deleteNodeLink={this.deleteNodeLink} /> : null }
                { this.state.data.focusedNodeId ? <NodeConfigPanel data={this.state.data} onDataUpdate={this.onDataUpdate} onNodeConfigPanelFullscreenToggle={this.onNodeConfigPanelFullscreenToggle} nodeConfigPanel_Fullscreen={this.state.displayControl.nodeConfigPanel_Fullscreen} /> : null }
                <div className="Builder-graphControlPanel">
                    <ButtonTooltip color='primary' type='icon' icon='project-diagram' id='new-graph' tooltipPlacement='top' tooltipText='Create a new pipeline' />{' '}
                    <ButtonTooltip color='primary' type='icon' icon='plus' id='new-node' tooltipPlacement='top' tooltipText='Add a node' onClick={this.onCreateNodeModalToggle} />{' '}
                    <ButtonTooltip color='primary' type='icon' icon='download' id='download-graph' tooltipPlacement='top' tooltipText='Download pipeline' />{' '}
                </div>
                <div className="Builder-container_graph">
                    <Graph ref="graph" {...graphProps} />
                </div>
            </div>
        );
    }
}

export default Builder;
