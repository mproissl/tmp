// React base
import React, { Component } from 'react';
import { Link } from 'react-router-dom';

// Styles
import logo from '../../img/ubs-logo-keys.svg';
import './Home.css';

class Home extends Component {
  render() {
    return (
      <div className="Home">
        <header className="Home-header">
          <img src={logo} className="Home-logo" alt="logo" />
          <p>
            Welcome to UBS Analytics Pipeline Builder.
          </p>
          <Link to='/builder'>Launch</Link>
        </header>
      </div>
    );
  }
}

export default Home;
