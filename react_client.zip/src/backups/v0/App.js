import React, { Component } from 'react';
import ubslogo from './img/ubs-logo-keys.svg';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={ubslogo} className="App-logo" alt="logo" />
          <p>
            Welcome to UBS Analytics Graph Builder.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Launch
          </a>
        </header>
      </div>
    );
  }
}

export default App;
