// React base
import React, { Component } from 'react';

// Routing
import { Route } from 'react-router-dom';

// Views
import Home from './views/home/Home'
import Builder from './views/builder/Builder'

// Icons
import { library } from '@fortawesome/fontawesome-svg-core'
import { faAngleDoubleDown, faPlus, faProjectDiagram, faDownload, faAngleLeft, faAngleRight } from '@fortawesome/free-solid-svg-icons'
library.add(faAngleDoubleDown);
library.add(faProjectDiagram);
library.add(faDownload);
library.add(faAngleLeft);
library.add(faAngleRight);
library.add(faPlus);

// Main class
class App extends Component {
  render() {
    return (
      <div className="App">
        <Route exact path="/" component={Home} />
        <Route exact path="/builder" component={Builder} />
      </div>
    );
  }
}

// Publish
export default App;
