package com.ubs.analytics.ubsassist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UbsassistApplication {

	public static void main(String[] args) {
		SpringApplication.run(UbsassistApplication.class, args);
	}

}
