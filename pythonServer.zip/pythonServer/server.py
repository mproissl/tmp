#!/usr/bin/env python
"""Python Server

This module is a simple python server for consuming & processing 
messages from a RabbitMQ server. It interfaces with the
'request_processor' module, which executes the messages from 
the request queue.

Module: server.py

Author: M.Proissl

Todo:
    * Extend to Apache Kafka
"""

# Deps
import pika
import json
import request_processor

# Messaging Broker (mb) connection
# _________________________________________________________________________________________
mb_credentials = pika.PlainCredentials('guest', 'guest')
"""Pika connection credentials

Setting the access credentials to RabbitMQ server. Temp. we are using the guest access.
"""

mb_parameters  = pika.ConnectionParameters('rabbitmq.mgmt',5672,'/',mb_credentials)
"""Pika connection parameters

Setting the connection parameters to RabbitMQ server at port 5672.
"""

mb_connection  = pika.BlockingConnection(mb_parameters)
"""Pika connection

Establishing the connection to RabbitMQ server.
"""

# Channels
# _________________________________________________________________________________________
channel = mb_connection.channel()
"""RabbitMQ channel init

Create a new channel instance on RabbitMQ server.
"""

channel.queue_declare(queue='request_input_queue')
"""RabbitMQ request input queue

Declare a new queue for incoming requests.
"""

channel.queue_declare(queue='request_output_queue')
"""RabbitMQ request output queue

Declare a new queue for outgoing responses to requests.
"""

# Processing switchboard
# _________________________________________________________________________________________
def request_processor_switch(request):
    """A switchboard for incoming requests

    This is a switchboard for incoming requests, which are passed on for processing 
    to the respective backends (here these are on the localhost).

    Args:
        request (json): Input parameters from request queue

    Returns:
        json: Output parameters after processing the input parameters

    """

    # Default return
    default = {
        'PROC_STATUS': 0, # Error(0), Success(1)
        'PROC_MSG': 'Unknown processing request.'
    }

    # Switchboard
    switcher = {
        'test': request_processor.test(request), # call directly fcn of 'request_processor'
    }
    return switcher.get(request[0], default)

# Processing requests
# _________________________________________________________________________________________
def callback(ch, method, properties, body):
    """A switchboard for incoming requests

    This is a switchboard for incoming requests, which are passed on for processing 
    to the respective backends (here these are on the localhost).

    Args:
        request (json): Input parameters from request queue

    Returns:
        json: Output parameters after processing the input parameters

    """

    # Load message body
    requestParams = json.loads(body.decode('utf-8'))

    # Call processor
    request_output = request_processor_switch(requestParams)

    # Return result to output queue
    channel.basic_publish(exchange='',
                          routing_key='request_output_queue',
                          body=json.dumps(request_output, ensure_ascii=False))

    # mb_connection.close()

# Server listen to inputs
# _________________________________________________________________________________________

# Trigger request processing on incoming message
channel.basic_consume(callback, queue='request_input_queue', no_ack=True)
"""Consume messages on input queue

Consumes request messages on input queue and triggers processing with callback.
"""

# Listen to input requests
print('$> Server listening on request_input_queue ...')
try:
    channel.start_consuming()
except KeyboardInterrupt:
    channel.stop_consuming()
    mb_connection.close()
