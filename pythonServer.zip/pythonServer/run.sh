#!/bin/sh
set -ex
docker run -it --rm --name='pyserver' \
              --network='localnet' \
              -v "$PWD":/usr/src/myapp \
              -w /usr/src/myapp \ 
	      pyserver:latest \
              python server.py

