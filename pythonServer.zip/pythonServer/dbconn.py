#!/usr/bin/env python
"""Handle database connections

This module currently only handles connections with MongoDB 
instances, but is expected to extend to others as well.

Module: dbconn.py

Authors: M.Proissl, D.Lussi

Todo:
    * Extend features (...)
"""

# Deps
from pymongo import MongoClient

# Simple communication test
# _________________________________________________________________________________________
def init(connStr):

    client = MongoClient(connStr)

    # TO be extended
    return client

