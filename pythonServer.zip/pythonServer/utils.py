#!/usr/bin/env python
"""Utility module

This module contains useful abstract (general) methods / snippets, which 
can be used reused and combined into new more complex methods.

Whenever possible, please use these coding guidlines for clean & maintainable 
code: https://google.github.io/styleguide/pyguide.html (e.g. run pylint)

Module: utils.py

Authors: M.Proissl, D.Lussi
"""
