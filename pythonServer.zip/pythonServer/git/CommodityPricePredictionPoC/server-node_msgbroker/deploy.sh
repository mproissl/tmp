#!/bin/sh
set -ex
docker run -d --name='rabbitmq.mgmt' \
              --network='localnet' \
	          --restart always \
              --hostname fsrisk.sams.ey.net \
              -p 8080:15672 \
	          rabbitmq:management
