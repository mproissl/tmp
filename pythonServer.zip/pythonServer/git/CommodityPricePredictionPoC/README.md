## Overview

This repository is part of the _commodity price prediction proof of concept_ at Mitsubishi and focuses on the development of an evaluation tool consisting of 
three nodes:

* MEAN client-server stack for user interactions;
* Message Broker for distributed communication with backends;
* Python Compute backend for handling user requests (e.g. data processing, modeling).
