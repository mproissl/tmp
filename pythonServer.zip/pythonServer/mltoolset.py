#!/usr/bin/env python
"""Machine learning toolset module

This module combines all machine learning methods and may be used as an 
API to interface with complex model creation & evaluation routines.

Whenever possible, please use these coding guidlines for clean & maintainable 
code: https://google.github.io/styleguide/pyguide.html (e.g. run pylint)

Module: mltoolset.py

Authors: M.Proissl, D.Lussi
"""
