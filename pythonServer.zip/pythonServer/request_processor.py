#!/usr/bin/env python
"""Request processing module

This module processes user requests and returns respective response messages. 
All requests are expected to contain at index 0 the name of the called function. 
All other parameters must be validated. The return message should contain at 
index 0 and 1 the PROC_STATUS (0: Error, 1: Success) and PROC_MSG (info) 
respectively.

Whenever possible, please use these coding guidlines for clean & maintainable 
code: https://google.github.io/styleguide/pyguide.html (e.g. run pylint)

Module: request_processor.py

Authors: M.Proissl, D.Lussi
"""

# Deps
import sys
import datahub
import mltoolset
import utils
import logging

# Logger
LOG_FORMAT = ('%(levelname) -10s %(asctime)s %(name) -30s %(funcName) '
              '-35s %(lineno) -5d: %(message)s')
LOGGER = logging.getLogger(__name__)

# Simple communication test
# _________________________________________________________________________________________
def test(request):

    # Default return
    fcnReturn = {
        'PROC_STATUS': 0, # Error(0), Success(1)
        'PROC_MSG': 'Error or Success msg',
        'FCN_CALL': request[0]
    }
    return fcnReturn

