#!/usr/bin/env python
"""Data provider module

This module coordinates all data feeds: from static files, databases or 
external (streaming) resources.

Whenever possible, please use these coding guidlines for clean & maintainable 
code: https://google.github.io/styleguide/pyguide.html (e.g. run pylint)

Module: datahub.py

Authors: M.Proissl, D.Lussi
"""

# Deps
import dbconn
import quandl

